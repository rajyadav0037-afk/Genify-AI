import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import GenerateStory from "@/pages/generate-story";
import GenerateImage from "@/pages/generate-image";
import GenerateShorts from "@/pages/generate-shorts";
import GenerateVideo from "@/pages/generate-video";
import Upgrade from "@/pages/upgrade";
import Admin from "@/pages/admin";
import ServerHealth from "@/pages/server-health";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      {/* Protected Routes */}
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/generate/story" component={GenerateStory} />
      <Route path="/generate/image" component={GenerateImage} />
      <Route path="/generate/shorts" component={GenerateShorts} />
      <Route path="/generate/video" component={GenerateVideo} />
      <Route path="/upgrade" component={Upgrade} />
      <Route path="/admin" component={Admin} />
      <Route path="/server-health" component={ServerHealth} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
            <Toaster />
          </AuthProvider>
        </WouterRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
