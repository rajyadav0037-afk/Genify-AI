import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useGetAdminStats, useGetAdminUsers, useGetAdminPayments, useApprovePayment, getGetAdminStatsQueryKey, getGetAdminUsersQueryKey, getGetAdminPaymentsQueryKey } from "@workspace/api-client-react";
import { Redirect } from "wouter";
import { Users, CreditCard, Activity, Database, CheckCircle, Clock } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: isLoadingStats } = useGetAdminStats({
    query: { enabled: !!user?.isAdmin }
  });
  
  const { data: users, isLoading: isLoadingUsers } = useGetAdminUsers({
    query: { enabled: !!user?.isAdmin }
  });
  
  const { data: payments, isLoading: isLoadingPayments } = useGetAdminPayments({
    query: { enabled: !!user?.isAdmin }
  });

  const approvePayment = useApprovePayment();

  if (!user?.isAdmin && user) {
    return <Redirect to="/dashboard" />;
  }

  const handleApprove = (paymentId: number) => {
    approvePayment.mutate({ id: paymentId }, {
      onSuccess: () => {
        toast({
          title: "Payment Approved",
          description: "The user's subscription has been activated.",
        });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminUsersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminPaymentsQueryKey() });
      },
      onError: (error) => {
        toast({
          title: "Approval failed",
          description: error.message || "Failed to approve payment.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">System overview and management</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingStats ? <Skeleton className="h-8 w-20" /> : (
                <>
                  <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    +{stats?.recentSignups || 0} in last 30 days
                  </p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Paid Subscribers</CardTitle>
              <CreditCard className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              {isLoadingStats ? <Skeleton className="h-8 w-20" /> : (
                <>
                  <div className="text-2xl font-bold text-primary">{stats?.paidUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats?.totalUsers ? Math.round(((stats?.paidUsers || 0) / stats.totalUsers) * 100) : 0}% conversion rate
                  </p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <Activity className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              {isLoadingStats ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-2xl font-bold">${stats?.totalRevenue || 0}</div>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Generations</CardTitle>
              <Database className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              {isLoadingStats ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-2xl font-bold">{stats?.totalGenerations || 0}</div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Pending Payments */}
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-500" />
                <CardTitle>Pending Payments</CardTitle>
                {stats?.pendingPayments > 0 && (
                  <Badge variant="secondary" className="ml-2 bg-amber-500/20 text-amber-500 hover:bg-amber-500/20">
                    {stats.pendingPayments} New
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingPayments ? (
                <div className="p-6 space-y-4">
                  {[1, 2].map(i => <Skeleton key={i} className="h-16 w-full" />)}
                </div>
              ) : payments && payments.length > 0 ? (
                <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
                  {payments.filter(p => p.status === 'pending').map((payment) => (
                    <div key={payment.id} className="p-4 flex flex-col gap-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-medium">{payment.userEmail}</div>
                          <div className="text-xs text-muted-foreground font-mono mt-1">Trx: {payment.transactionId}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-lg">${payment.amount}</div>
                          <div className="text-xs text-muted-foreground">{format(new Date(payment.createdAt), "MMM d, yyyy")}</div>
                        </div>
                      </div>
                      {payment.notes && (
                        <div className="text-sm text-muted-foreground bg-muted/50 p-2 rounded italic">
                          "{payment.notes}"
                        </div>
                      )}
                      <Button 
                        size="sm" 
                        className="w-full sm:w-auto self-end mt-2" 
                        onClick={() => handleApprove(payment.id)}
                        disabled={approvePayment.isPending}
                        data-testid={`btn-approve-${payment.id}`}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Approve Payment
                      </Button>
                    </div>
                  ))}
                  {payments.filter(p => p.status === 'pending').length === 0 && (
                    <div className="p-8 text-center text-muted-foreground">
                      No pending payments to review.
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  No payments found.
                </div>
              )}
            </CardContent>
          </Card>

          {/* User Directory */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>User Directory</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingUsers ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : (
                <div className="max-h-[400px] overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead>User</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Gens</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users?.map((u) => (
                        <TableRow key={u.id} data-testid={`user-row-${u.id}`}>
                          <TableCell className="font-medium">
                            <div className="truncate max-w-[150px]" title={u.email}>{u.email}</div>
                            <div className="text-[10px] text-muted-foreground">{format(new Date(u.createdAt), "MMM d, yyyy")}</div>
                          </TableCell>
                          <TableCell>
                            {u.isSubscribed ? (
                              <Badge variant="secondary" className="bg-primary/20 text-primary">PRO</Badge>
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground border-muted-foreground/30">Free</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right font-mono text-sm">
                            {u.totalGenerations}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
