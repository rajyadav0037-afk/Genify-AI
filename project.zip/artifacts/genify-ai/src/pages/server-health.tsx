import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Database,
  Cpu,
  Clock,
  MemoryStick,
  Wifi,
  WifiOff,
  RefreshCw,
  KeyRound,
} from "lucide-react";

interface HealthData {
  status: string;
  database: {
    connected: string;
    latencyMs: number | null;
  };
  openai: string;
  uptime: {
    ms: number;
    human: string;
  };
  memory: {
    rssMB: number;
    heapUsedMB: number;
    heapTotalMB: number;
    externalMB: number;
  };
  time: string;
}

function StatCard({
  title,
  icon: Icon,
  children,
  isLoading,
}: {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  isLoading: boolean;
}) {
  return (
    <Card className="bg-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? <Skeleton className="h-8 w-32 mt-1" /> : children}
      </CardContent>
    </Card>
  );
}

function MemoryBar({ used, total, label }: { used: number; total: number; label: string }) {
  const pct = total > 0 ? Math.min(100, Math.round((used / total) * 100)) : 0;
  const color = pct > 85 ? "bg-red-500" : pct > 65 ? "bg-amber-500" : "bg-primary";
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{label}</span>
        <span>{used} / {total} MB ({pct}%)</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-500 ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default function ServerHealth() {
  const { data, isLoading, isError, dataUpdatedAt } = useQuery<HealthData>({
    queryKey: ["server-health"],
    queryFn: async () => {
      const res = await fetch("/api/healthz");
      if (!res.ok) throw new Error("Health check failed");
      return res.json();
    },
    refetchInterval: 5000,
    retry: false,
  });

  const isOnline = data?.status === "OK";
  const isDbConnected = data?.database?.connected === "Connected";
  const isAiReady = data?.openai === "Key Present";
  const lastChecked = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : null;

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Server Health</h1>
            <p className="text-muted-foreground mt-1">Live system status — refreshes every 5 seconds</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2">
            <RefreshCw className="h-3 w-3" />
            {lastChecked ? `Last checked: ${lastChecked}` : "Checking…"}
          </div>
        </div>

        {/* Overall Status Banner */}
        <Card className={`border ${isError ? "border-red-500/40 bg-red-500/5" : isOnline ? "border-green-500/40 bg-green-500/5" : "border-border"}`}>
          <CardContent className="flex items-center gap-4 py-4">
            <span className="relative flex h-4 w-4">
              {isLoading ? (
                <span className="h-4 w-4 rounded-full bg-muted animate-pulse" />
              ) : isOnline ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex h-4 w-4 rounded-full bg-green-500" />
                </>
              ) : (
                <span className="relative inline-flex h-4 w-4 rounded-full bg-red-500" />
              )}
            </span>
            <div>
              <div className="font-semibold">
                {isLoading ? "Checking…" : isError ? "Server Unreachable" : "All Systems Operational"}
              </div>
              {data?.time && (
                <div className="text-xs text-muted-foreground mt-0.5">
                  Server time: {new Date(data.time).toLocaleString()}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Stat Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Database */}
          <StatCard title="Database" icon={Database} isLoading={isLoading}>
            <div className="flex items-center gap-2 mt-1">
              {isDbConnected ? (
                <Wifi className="h-5 w-5 text-green-500" />
              ) : (
                <WifiOff className="h-5 w-5 text-red-500" />
              )}
              <span className="text-xl font-bold">{data?.database.connected}</span>
            </div>
            {data?.database.latencyMs != null && (
              <p className="text-xs text-muted-foreground mt-1">
                Latency: <span className="font-mono">{data.database.latencyMs} ms</span>
              </p>
            )}
          </StatCard>

          {/* OpenAI */}
          <StatCard title="OpenAI Key" icon={KeyRound} isLoading={isLoading}>
            <div className="mt-1">
              <Badge
                variant="secondary"
                className={isAiReady ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"}
              >
                {data?.openai}
              </Badge>
            </div>
          </StatCard>

          {/* Uptime */}
          <StatCard title="Uptime" icon={Clock} isLoading={isLoading}>
            <div className="text-xl font-bold font-mono mt-1">{data?.uptime.human}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Since last restart
            </p>
          </StatCard>

          {/* RSS Memory */}
          <StatCard title="Process Memory" icon={Cpu} isLoading={isLoading}>
            <div className="text-xl font-bold mt-1">{data?.memory.rssMB} <span className="text-sm font-normal text-muted-foreground">MB RSS</span></div>
            <p className="text-xs text-muted-foreground mt-1">
              External: {data?.memory.externalMB} MB
            </p>
          </StatCard>
        </div>

        {/* Memory Detail */}
        <Card className="bg-card">
          <CardHeader className="flex flex-row items-center gap-2 pb-4">
            <MemoryStick className="h-5 w-5 text-muted-foreground" />
            <CardTitle>Heap Memory</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-full" />
              </div>
            ) : data ? (
              <>
                <MemoryBar
                  label="Heap Used"
                  used={data.memory.heapUsedMB}
                  total={data.memory.heapTotalMB}
                />
                <MemoryBar
                  label="Heap Total vs RSS"
                  used={data.memory.heapTotalMB}
                  total={data.memory.rssMB}
                />
              </>
            ) : (
              <p className="text-sm text-muted-foreground">No data available.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
