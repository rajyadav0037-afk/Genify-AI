import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGenerateShorts } from "@workspace/api-client-react";
import { Film, AlertCircle, Wand2 } from "lucide-react";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";

export default function GenerateShorts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const generateShorts = useGenerateShorts();

  const isOutOfCredits = !user?.isSubscribed && user?.freeUsage === 0;

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to generate a Shorts script.",
        variant: "destructive"
      });
      return;
    }

    generateShorts.mutate({ data: { prompt } }, {
      onSuccess: () => {
        toast({
          title: "Script Generated!",
          description: "Your YouTube Shorts script has been created successfully.",
        });
      },
      onError: (error) => {
        toast({
          title: "Generation failed",
          description: error.message || "Failed to generate shorts script",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-400/10 rounded-xl border border-purple-400/20">
            <Film className="h-6 w-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Shorts AI</h1>
            <p className="text-muted-foreground mt-1">Create viral short-form scripts for TikTok and Reels</p>
          </div>
        </div>

        {isOutOfCredits && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Out of credits</AlertTitle>
            <AlertDescription className="flex items-center justify-between mt-2">
              <span>You have reached your free generation limit. Upgrade to Pro for unlimited access.</span>
              <Link href="/upgrade">
                <Button size="sm" variant="destructive">Upgrade Now</Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-card border-border">
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <label htmlFor="prompt" className="text-sm font-medium text-foreground">
                What's the topic for your short?
              </label>
              <Textarea
                id="prompt"
                placeholder="5 psychological tricks to make people like you instantly..."
                className="min-h-[150px] resize-y bg-background text-foreground"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={generateShorts.isPending || isOutOfCredits}
                data-testid="input-prompt"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {!user?.isSubscribed ? `${user?.freeUsage || 0} generations remaining` : 'Unlimited generations'}
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={generateShorts.isPending || isOutOfCredits || !prompt.trim()}
                className="min-w-[150px] bg-purple-600 hover:bg-purple-700 text-white"
                data-testid="btn-generate"
              >
                {generateShorts.isPending ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Script
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {generateShorts.data && (
          <Card className="bg-card border-purple-400/30 shadow-lg shadow-purple-400/5 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardHeader className="border-b border-border/50 pb-4 bg-muted/20">
              <CardTitle className="text-lg">Generated Result</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="prose prose-invert max-w-none whitespace-pre-wrap text-foreground leading-relaxed" data-testid="text-result">
                {generateShorts.data.short}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
