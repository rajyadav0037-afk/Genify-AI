import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useGetGenerationHistory } from "@workspace/api-client-react";
import { BookOpen, Image as ImageIcon, Film, Video, Clock, Zap, ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: history, isLoading } = useGetGenerationHistory();

  const tools = [
    {
      title: "Story AI",
      description: "Write compelling narratives and articles",
      icon: <BookOpen className="h-8 w-8 text-primary" />,
      href: "/generate/story",
      color: "bg-primary/10 border-primary/20"
    },
    {
      title: "Image AI",
      description: "Generate stunning high-res visuals",
      icon: <ImageIcon className="h-8 w-8 text-blue-400" />,
      href: "/generate/image",
      color: "bg-blue-400/10 border-blue-400/20"
    },
    {
      title: "Shorts AI",
      description: "Create viral short-form scripts",
      icon: <Film className="h-8 w-8 text-purple-400" />,
      href: "/generate/shorts",
      color: "bg-purple-400/10 border-purple-400/20"
    },
    {
      title: "Video AI",
      description: "Develop full YouTube video concepts",
      icon: <Video className="h-8 w-8 text-pink-400" />,
      href: "/generate/video",
      color: "bg-pink-400/10 border-pink-400/20"
    }
  ];

  return (
    <AppLayout>
      <div className="space-y-8">
        
        {/* Header & Usage */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Welcome back. What are we creating today?</p>
          </div>
          
          <Card className="bg-card border-border shadow-sm min-w-[240px]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Usage Status</p>
                <div className="flex items-baseline gap-2">
                  {user?.isSubscribed ? (
                    <>
                      <span className="text-2xl font-bold text-primary" data-testid="text-usage">Unlimited</span>
                      <Badge variant="secondary" className="bg-primary/20 text-primary hover:bg-primary/30">PRO</Badge>
                    </>
                  ) : (
                    <>
                      <span className="text-2xl font-bold" data-testid="text-usage">{user?.freeUsage}</span>
                      <span className="text-sm text-muted-foreground">generations left</span>
                    </>
                  )}
                </div>
              </div>
              {!user?.isSubscribed && (
                <Link href="/upgrade">
                  <Button size="sm" className="ml-4" data-testid="btn-upgrade-prompt">Upgrade</Button>
                </Link>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {tools.map((tool) => (
            <Link key={tool.title} href={tool.href}>
              <Card className="hover:border-primary/50 transition-all cursor-pointer h-full bg-card group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardContent className="p-6 flex flex-col h-full">
                  <div className={`p-3 rounded-xl w-fit mb-4 border ${tool.color}`}>
                    {tool.icon}
                  </div>
                  <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{tool.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">{tool.description}</p>
                  <div className="flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-[-10px] group-hover:translate-x-0 duration-300">
                    Generate <ArrowRight className="ml-1 h-4 w-4" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Recent History */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-xl font-bold">Recent Generations</h2>
          </div>
          
          <Card className="bg-card">
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex gap-4">
                      <Skeleton className="h-12 w-12 rounded-lg" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-1/4" />
                        <Skeleton className="h-4 w-full" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : history && history.length > 0 ? (
                <div className="divide-y divide-border">
                  {history.map((item) => (
                    <div key={item.id} className="p-4 md:p-6 flex flex-col md:flex-row gap-4 md:items-center hover:bg-muted/50 transition-colors" data-testid={`history-item-${item.id}`}>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="uppercase text-[10px] font-bold tracking-wider">
                            {item.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(item.createdAt), "MMM d, h:mm a")}
                          </span>
                        </div>
                        <p className="text-sm font-medium truncate text-foreground" title={item.prompt}>
                          {item.prompt}
                        </p>
                      </div>
                      <div className="flex-shrink-0">
                        {/* We don't have a direct "view" page yet, but could be added. For now just show snippet */}
                        <Button variant="secondary" size="sm" className="w-full md:w-auto pointer-events-none">
                          Generated
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center flex flex-col items-center">
                  <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
                    <Zap className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium text-lg mb-1">No history yet</h3>
                  <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                    Your generated content will appear here. Start creating using one of the tools above.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
