import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGenerateVideo } from "@workspace/api-client-react";
import { Video, AlertCircle, Wand2 } from "lucide-react";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";

export default function GenerateVideo() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const generateVideo = useGenerateVideo();

  const isOutOfCredits = !user?.isSubscribed && user?.freeUsage === 0;

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to generate a video concept.",
        variant: "destructive"
      });
      return;
    }

    generateVideo.mutate({ data: { prompt } }, {
      onSuccess: () => {
        toast({
          title: "Concept Generated!",
          description: "Your video concept and script have been created successfully.",
        });
      },
      onError: (error) => {
        toast({
          title: "Generation failed",
          description: error.message || "Failed to generate video concept",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-pink-400/10 rounded-xl border border-pink-400/20">
            <Video className="h-6 w-6 text-pink-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Video AI</h1>
            <p className="text-muted-foreground mt-1">Develop comprehensive YouTube video concepts and shot lists</p>
          </div>
        </div>

        {isOutOfCredits && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Out of credits</AlertTitle>
            <AlertDescription className="flex items-center justify-between mt-2">
              <span>You have reached your free generation limit. Upgrade to Pro for unlimited access.</span>
              <Link href="/upgrade">
                <Button size="sm" variant="destructive">Upgrade Now</Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-card border-border">
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <label htmlFor="prompt" className="text-sm font-medium text-foreground">
                What's the core idea of your video?
              </label>
              <Textarea
                id="prompt"
                placeholder="A comprehensive review of the latest tech gadgets focusing on smart home automation..."
                className="min-h-[150px] resize-y bg-background text-foreground"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={generateVideo.isPending || isOutOfCredits}
                data-testid="input-prompt"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {!user?.isSubscribed ? `${user?.freeUsage || 0} generations remaining` : 'Unlimited generations'}
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={generateVideo.isPending || isOutOfCredits || !prompt.trim()}
                className="min-w-[150px] bg-pink-600 hover:bg-pink-700 text-white"
                data-testid="btn-generate"
              >
                {generateVideo.isPending ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Concept
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {generateVideo.data && (
          <Card className="bg-card border-pink-400/30 shadow-lg shadow-pink-400/5 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardHeader className="border-b border-border/50 pb-4 bg-muted/20">
              <CardTitle className="text-lg">Generated Result</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="prose prose-invert max-w-none whitespace-pre-wrap text-foreground leading-relaxed" data-testid="text-result">
                {generateVideo.data.video}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
