import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGenerateImage } from "@workspace/api-client-react";
import { Image as ImageIcon, AlertCircle, Wand2, Download } from "lucide-react";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";

export default function GenerateImage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const generateImage = useGenerateImage();

  const isOutOfCredits = !user?.isSubscribed && user?.freeUsage === 0;

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to generate an image.",
        variant: "destructive"
      });
      return;
    }

    generateImage.mutate({ data: { prompt } }, {
      onSuccess: () => {
        toast({
          title: "Image Generated!",
          description: "Your image has been created successfully.",
        });
      },
      onError: (error) => {
        toast({
          title: "Generation failed",
          description: error.message || "Failed to generate image",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-400/10 rounded-xl border border-blue-400/20">
            <ImageIcon className="h-6 w-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Image AI</h1>
            <p className="text-muted-foreground mt-1">Generate stunning high-res visuals</p>
          </div>
        </div>

        {isOutOfCredits && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Out of credits</AlertTitle>
            <AlertDescription className="flex items-center justify-between mt-2">
              <span>You have reached your free generation limit. Upgrade to Pro for unlimited access.</span>
              <Link href="/upgrade">
                <Button size="sm" variant="destructive">Upgrade Now</Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-card border-border">
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <label htmlFor="prompt" className="text-sm font-medium text-foreground">
                Describe the image you want to see
              </label>
              <Textarea
                id="prompt"
                placeholder="A futuristic city cyberpunk style, neon lights reflecting on wet streets, 4k resolution..."
                className="min-h-[100px] resize-y bg-background text-foreground"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={generateImage.isPending || isOutOfCredits}
                data-testid="input-prompt"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {!user?.isSubscribed ? `${user?.freeUsage || 0} generations remaining` : 'Unlimited generations'}
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={generateImage.isPending || isOutOfCredits || !prompt.trim()}
                className="min-w-[150px] bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="btn-generate"
              >
                {generateImage.isPending ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Image
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {generateImage.data && (
          <Card className="bg-card border-blue-400/30 shadow-lg shadow-blue-400/5 animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-hidden">
            <CardHeader className="border-b border-border/50 pb-4 bg-muted/20 flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Generated Result</CardTitle>
              <a href={generateImage.data.image} target="_blank" rel="noreferrer" download>
                <Button variant="ghost" size="sm" title="Download">
                  <Download className="h-4 w-4 mr-2" />
                  Open Full Size
                </Button>
              </a>
            </CardHeader>
            <CardContent className="p-6 flex justify-center bg-background/50">
              <img 
                src={generateImage.data.image} 
                alt={prompt} 
                className="max-w-full h-auto rounded-lg shadow-md border border-border"
                data-testid="img-result"
              />
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
