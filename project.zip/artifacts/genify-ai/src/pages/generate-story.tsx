import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGenerateStory } from "@workspace/api-client-react";
import { BookOpen, AlertCircle, Wand2 } from "lucide-react";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";

export default function GenerateStory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const generateStory = useGenerateStory();

  const isOutOfCredits = !user?.isSubscribed && user?.freeUsage === 0;

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to generate a story.",
        variant: "destructive"
      });
      return;
    }

    generateStory.mutate({ data: { prompt } }, {
      onSuccess: () => {
        toast({
          title: "Story Generated!",
          description: "Your story has been created successfully.",
        });
      },
      onError: (error) => {
        toast({
          title: "Generation failed",
          description: error.message || "Failed to generate story",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-primary/10 rounded-xl border border-primary/20">
            <BookOpen className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Story AI</h1>
            <p className="text-muted-foreground mt-1">Generate compelling narratives and articles</p>
          </div>
        </div>

        {isOutOfCredits && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Out of credits</AlertTitle>
            <AlertDescription className="flex items-center justify-between mt-2">
              <span>You have reached your free generation limit. Upgrade to Pro for unlimited access.</span>
              <Link href="/upgrade">
                <Button size="sm" variant="destructive">Upgrade Now</Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-card border-border">
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <label htmlFor="prompt" className="text-sm font-medium text-foreground">
                What story should we write?
              </label>
              <Textarea
                id="prompt"
                placeholder="A sci-fi short story about a rogue AI who discovers painting..."
                className="min-h-[150px] resize-y bg-background text-foreground"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={generateStory.isPending || isOutOfCredits}
                data-testid="input-prompt"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {!user?.isSubscribed ? `${user?.freeUsage || 0} generations remaining` : 'Unlimited generations'}
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={generateStory.isPending || isOutOfCredits || !prompt.trim()}
                className="min-w-[150px]"
                data-testid="btn-generate"
              >
                {generateStory.isPending ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Story
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {generateStory.data && (
          <Card className="bg-card border-primary/30 shadow-lg shadow-primary/5 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardHeader className="border-b border-border/50 pb-4 bg-muted/20">
              <CardTitle className="text-lg">Generated Result</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="prose prose-invert max-w-none whitespace-pre-wrap text-foreground leading-relaxed" data-testid="text-result">
                {generateStory.data.story}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
