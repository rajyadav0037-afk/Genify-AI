import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useSubmitPayment, getGetMeQueryKey } from "@workspace/api-client-react";
import { Zap, Check, Upload, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const paymentSchema = z.object({
  transactionId: z.string().min(5, "Transaction ID is required"),
  amount: z.coerce.number().min(29, "Minimum amount is $29"),
  notes: z.string().optional(),
});

export default function Upgrade() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const submitPayment = useSubmitPayment();

  const form = useForm<z.infer<typeof paymentSchema>>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      transactionId: "",
      amount: 29,
      notes: "",
    },
  });

  const onSubmit = (values: z.infer<typeof paymentSchema>) => {
    submitPayment.mutate({ data: values }, {
      onSuccess: () => {
        toast({
          title: "Payment submitted",
          description: "Your payment proof has been submitted and is pending review.",
        });
        form.reset();
        // Refresh user data just in case
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      },
      onError: (error) => {
        toast({
          title: "Submission failed",
          description: error.message || "Failed to submit payment proof",
          variant: "destructive"
        });
      }
    });
  };

  if (user?.isSubscribed) {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto mt-12">
          <Card className="bg-primary/5 border-primary/20 p-12 text-center flex flex-col items-center">
            <div className="h-16 w-16 bg-primary/20 rounded-full flex items-center justify-center mb-6">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-4">Your account is active!</h1>
            <p className="text-muted-foreground text-lg max-w-md">
              You are currently on the Pro Studio plan with unlimited generations and priority processing.
            </p>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Upgrade to Pro Studio</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Unlock the full power of Genify AI with unlimited generations across all tools.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-start">
          {/* Plan Details */}
          <Card className="bg-card border-primary/30 relative">
            <div className="absolute top-0 right-8 transform -translate-y-1/2">
              <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                Pro Plan
              </span>
            </div>
            <CardHeader className="pb-4 border-b border-border/50">
              <CardTitle className="text-2xl font-bold">Pro Studio</CardTitle>
              <div className="mt-4 flex items-baseline text-4xl font-bold text-foreground">
                $29<span className="text-lg text-muted-foreground font-normal ml-1">/month</span>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <ul className="space-y-4">
                {[
                  "Unlimited Generations",
                  "Access to Story, Image, Shorts, & Video AI",
                  "Priority generation speed",
                  "Premium 24/7 support",
                  "Commercial usage rights",
                  "Early access to new features"
                ].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <div className="bg-primary/20 p-1 rounded-full">
                      <Check className="h-4 w-4 text-primary" />
                    </div>
                    <span className={i === 0 ? 'font-medium text-foreground' : 'text-muted-foreground'}>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Submit Payment</CardTitle>
              <CardDescription>
                Transfer funds to our account and submit the transaction ID below for manual verification.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-muted/50 p-4 rounded-lg border border-border mb-6 text-sm font-mono text-muted-foreground">
                <p>Bank: Tech Startup Bank</p>
                <p>Account Name: Genify AI Inc.</p>
                <p>Account Number: 1234-5678-9012</p>
                <p>Amount: $29.00</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="transactionId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Transaction ID / Reference Number</FormLabel>
                        <FormControl>
                          <Input placeholder="TRX-..." {...field} data-testid="input-transaction" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount Paid ($)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} data-testid="input-amount" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Any additional details..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full mt-4" 
                    disabled={submitPayment.isPending}
                    data-testid="btn-submit-payment"
                  >
                    {submitPayment.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Submit for Verification
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
