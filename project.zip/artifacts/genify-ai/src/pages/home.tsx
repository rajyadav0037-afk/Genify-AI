import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Zap, Image as ImageIcon, BookOpen, Video, Film, ChevronRight, Check } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <nav className="h-16 border-b border-border/40 px-4 md:px-8 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur z-50">
        <div className="flex items-center gap-2">
          <Zap className="h-6 w-6 text-primary fill-primary" />
          <span className="font-bold text-xl tracking-tight">Genify<span className="text-primary">AI</span></span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/login">
            <Button variant="ghost" className="hidden sm:flex" data-testid="link-login">Sign In</Button>
          </Link>
          <Link href="/register">
            <Button data-testid="link-register">Get Started</Button>
          </Link>
        </div>
      </nav>

      <main className="flex-1 flex flex-col items-center">
        {/* Hero Section */}
        <section className="w-full max-w-5xl mx-auto px-4 py-24 md:py-32 flex flex-col items-center text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-4">
            <Zap className="h-4 w-4" />
            <span>The Next Generation Creative Studio</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-foreground max-w-4xl leading-tight">
            Create <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">anything</span>. <br />
            At the speed of thought.
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Stories, images, YouTube shorts, and video concepts. Professional-grade AI generation for creators who move fast and demand the best.
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-4 pt-8">
            <Link href="/register">
              <Button size="lg" className="h-14 px-8 text-lg w-full sm:w-auto" data-testid="btn-hero-cta">
                Start Creating for Free <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <p className="text-sm text-muted-foreground sm:hidden">No credit card required</p>
          </div>
        </section>

        {/* Features Section */}
        <section className="w-full bg-card border-y border-border/40 py-24">
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">One Studio. Four Superpowers.</h2>
              <p className="text-muted-foreground text-lg">Everything you need to dominate your content pipeline.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FeatureCard 
                icon={<BookOpen className="h-8 w-8 text-primary" />}
                title="Story AI"
                description="Generate compelling narratives, blog posts, and articles with character depth and engaging pacing."
              />
              <FeatureCard 
                icon={<ImageIcon className="h-8 w-8 text-blue-400" />}
                title="Image AI"
                description="Create stunning, high-resolution visuals from simple text prompts. Studio quality, instantly."
              />
              <FeatureCard 
                icon={<Film className="h-8 w-8 text-purple-400" />}
                title="Shorts AI"
                description="Viral-ready scripts for TikTok, Reels, and Shorts. Hook, value, and CTA perfectly structured."
              />
              <FeatureCard 
                icon={<Video className="h-8 w-8 text-pink-400" />}
                title="Video AI"
                description="Comprehensive video concepts, shot lists, and full scripts for long-form YouTube content."
              />
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="w-full max-w-5xl mx-auto px-4 py-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-muted-foreground text-lg">Start for free, upgrade when you're ready to scale.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            <Card className="p-8 bg-card border-border/50 flex flex-col">
              <div className="mb-8">
                <h3 className="text-2xl font-bold mb-2">Creator Free</h3>
                <p className="text-muted-foreground">Perfect for testing the waters.</p>
                <div className="mt-4 flex items-baseline text-4xl font-bold">
                  $0<span className="text-lg text-muted-foreground font-normal ml-1">/forever</span>
                </div>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                <PricingFeature text="2 Generations included" />
                <PricingFeature text="Access to all 4 AI tools" />
                <PricingFeature text="Standard generation speed" />
                <PricingFeature text="Community support" />
              </ul>
              <Link href="/register" className="mt-auto">
                <Button variant="outline" className="w-full h-12 text-lg">Get Started</Button>
              </Link>
            </Card>

            <Card className="p-8 bg-primary/5 border-primary/30 relative flex flex-col">
              <div className="absolute top-0 right-8 transform -translate-y-1/2">
                <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Most Popular
                </span>
              </div>
              <div className="mb-8">
                <h3 className="text-2xl font-bold mb-2 text-foreground">Pro Studio</h3>
                <p className="text-muted-foreground">For serious creators who ship daily.</p>
                <div className="mt-4 flex items-baseline text-4xl font-bold text-foreground">
                  $29<span className="text-lg text-muted-foreground font-normal ml-1">/month</span>
                </div>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                <PricingFeature text="Unlimited Generations" highlighted />
                <PricingFeature text="Access to all 4 AI tools" />
                <PricingFeature text="Priority generation speed" />
                <PricingFeature text="Premium support" />
                <PricingFeature text="Commercial usage rights" />
              </ul>
              <Link href="/register" className="mt-auto">
                <Button className="w-full h-12 text-lg">Upgrade to Pro</Button>
              </Link>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/40 py-8 text-center text-muted-foreground">
        <p>© {new Date().getFullYear()} Genify AI. All rights reserved.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <Card className="p-6 bg-background/50 border-border/40 hover:border-primary/30 transition-colors">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </Card>
  );
}

function PricingFeature({ text, highlighted = false }: { text: string, highlighted?: boolean }) {
  return (
    <li className="flex items-center gap-3">
      <Check className={`h-5 w-5 ${highlighted ? 'text-primary' : 'text-muted-foreground'}`} />
      <span className={highlighted ? 'font-medium text-foreground' : 'text-muted-foreground'}>{text}</span>
    </li>
  );
}
