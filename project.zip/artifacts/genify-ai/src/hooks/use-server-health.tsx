import { useQuery } from "@tanstack/react-query";

interface HealthData {
  status: string;
  database: { connected: string; latencyMs: number | null };
  openai: string;
  uptime: { ms: number; human: string };
  memory: { rssMB: number; heapUsedMB: number; heapTotalMB: number; externalMB: number };
  time: string;
}

export function useServerHealth() {
  const { data, isError, isPending } = useQuery<HealthData>({
    queryKey: ["server-health"],
    queryFn: async () => {
      const res = await fetch("/api/healthz");
      if (!res.ok) throw new Error("Health check failed");
      return res.json();
    },
    refetchInterval: 15000,
    retry: 1,
    staleTime: 10000,
  });

  const isHealthy = !isError && data?.status === "OK";
  const isDbDown = !!data && data.database?.connected !== "Connected";
  const isAiMissing = !!data && data.openai !== "Key Present";

  let message: string | null = null;
  if (isError) {
    message = "Server is unreachable. Some features may not work.";
  } else if (isDbDown) {
    message = "Database connection lost. Generations may fail.";
  } else if (isAiMissing) {
    message = "OpenAI key is missing. AI features are disabled.";
  }

  return { isHealthy, message, data, isError };
}
