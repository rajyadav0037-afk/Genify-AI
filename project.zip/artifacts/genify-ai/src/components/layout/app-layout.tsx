import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useServerHealth } from "@/hooks/use-server-health";
import { Button } from "@/components/ui/button";
import { 
  Zap, 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  Menu,
  Image as ImageIcon,
  BookOpen,
  Video,
  Film,
  Activity,
  AlertTriangle,
  X
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const { message: healthMessage } = useServerHealth();
  const [dismissed, setDismissed] = useState(false);

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/generate/story", label: "Story AI", icon: BookOpen },
    { href: "/generate/image", label: "Image AI", icon: ImageIcon },
    { href: "/generate/shorts", label: "Shorts AI", icon: Film },
    { href: "/generate/video", label: "Video AI", icon: Video },
  ];

  if (user?.isAdmin) {
    navItems.push({ href: "/admin", label: "Admin Panel", icon: Settings });
    navItems.push({ href: "/server-health", label: "Server Health", icon: Activity });
  }

  const NavLinks = () => (
    <div className="space-y-1">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.href;
        return (
          <Link key={item.href} href={item.href} className="block">
            <Button
              variant={isActive ? "secondary" : "ghost"}
              className="w-full justify-start"
              data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <Icon className="mr-2 h-4 w-4" />
              {item.label}
            </Button>
          </Link>
        );
      })}
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col border-r border-border bg-card">
        <div className="p-6">
          <Link href="/dashboard" className="flex items-center gap-2 text-primary hover:opacity-90 transition-opacity">
            <Zap className="h-6 w-6 fill-primary" />
            <span className="font-bold text-xl tracking-tight text-foreground">Genify<span className="text-primary">AI</span></span>
          </Link>
        </div>
        
        <div className="px-4 py-2 flex-1">
          <NavLinks />
        </div>

        <div className="p-4 border-t border-border space-y-4">
          <div className="px-2">
            <div className="text-sm font-medium text-foreground truncate" data-testid="user-email">{user?.email}</div>
            <div className="text-xs text-muted-foreground mt-1 flex items-center justify-between">
              <span>{user?.isSubscribed ? 'Pro Plan' : 'Free Plan'}</span>
              {!user?.isSubscribed && (
                <Link href="/upgrade" className="text-primary hover:underline">
                  Upgrade
                </Link>
              )}
            </div>
          </div>
          <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-foreground" onClick={logout} data-testid="btn-logout">
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Nav */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 border-b border-border bg-background/80 backdrop-blur z-50 flex items-center justify-between px-4">
        <Link href="/dashboard" className="flex items-center gap-2 text-primary">
          <Zap className="h-5 w-5 fill-primary" />
          <span className="font-bold text-lg text-foreground">Genify<span className="text-primary">AI</span></span>
        </Link>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 bg-card border-r-border p-0 flex flex-col">
            <div className="p-6">
              <Link href="/dashboard" className="flex items-center gap-2 text-primary">
                <Zap className="h-6 w-6 fill-primary" />
                <span className="font-bold text-xl text-foreground">Genify<span className="text-primary">AI</span></span>
              </Link>
            </div>
            <div className="px-4 py-2 flex-1">
              <NavLinks />
            </div>
            <div className="p-4 border-t border-border space-y-4">
              <div className="px-2">
                <div className="text-sm font-medium text-foreground truncate">{user?.email}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {user?.isSubscribed ? 'Pro Plan' : 'Free Plan'}
                </div>
              </div>
              <Button variant="ghost" className="w-full justify-start text-muted-foreground" onClick={logout}>
                <LogOut className="mr-2 h-4 w-4" />
                Sign Out
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      <main className="flex-1 overflow-auto md:pt-0 pt-16">
        {healthMessage && !dismissed && (
          <div className="bg-amber-500/10 border-b border-amber-500/30 px-4 py-2.5 flex items-center gap-3 text-sm text-amber-600 dark:text-amber-400">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span className="flex-1">{healthMessage}</span>
            {user?.isAdmin && (
              <Link href="/server-health" className="underline underline-offset-2 hover:opacity-80 font-medium shrink-0">
                View Details
              </Link>
            )}
            <button
              onClick={() => setDismissed(true)}
              className="shrink-0 hover:opacity-70 transition-opacity ml-1"
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}
        <div className="max-w-6xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
