import { Router, type IRouter } from "express";
import jwt from "jsonwebtoken";
import { db, usersTable, generationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  GenerateStoryBody,
  GenerateImageBody,
  GenerateShortsBody,
  GenerateVideoBody,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import { JWT_SECRET, ADMIN_EMAIL } from "./auth";

const router: IRouter = Router();

async function authMiddleware(req: any, res: any): Promise<{ id: number; email: string } | null> {
  const authHeader = req.headers.authorization ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return null;
  }

  const token = authHeader.slice(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number; email: string };
    return decoded;
  } catch {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }
}

async function checkAndDecrementUsage(userId: number, email: string, feature: string): Promise<{ user: any; allowed: boolean }> {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) return { user: null, allowed: false };

  if (email === ADMIN_EMAIL || user.isAdmin || user.isSubscribed) {
    return { user, allowed: true };
  }

  if (user.freeUsage <= 0) {
    return { user, allowed: false };
  }

  const updateData: Record<string, any> = { freeUsage: user.freeUsage - 1 };
  if (feature === "image") updateData.usageImage = user.usageImage + 1;
  if (feature === "video") updateData.usageVideo = user.usageVideo + 1;
  if (feature === "story") updateData.usageStory = user.usageStory + 1;
  if (feature === "shorts") updateData.usageShorts = user.usageShorts + 1;

  await db.update(usersTable).set(updateData).where(eq(usersTable.id, userId));

  return { user, allowed: true };
}

router.post("/ai/story", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const parsed = GenerateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Prompt required" });
    return;
  }

  const { allowed } = await checkAndDecrementUsage(decoded.id, decoded.email, "story");
  if (!allowed) {
    res.status(403).json({ error: "Free usage limit reached. Please upgrade to continue." });
    return;
  }

  const completion = await openai.chat.completions.create({
    model: "gpt-5-mini",
    messages: [{ role: "user", content: parsed.data.prompt }],
  });

  const story = completion.choices?.[0]?.message?.content ?? "";

  await db.insert(generationsTable).values({
    userId: decoded.id,
    type: "story",
    prompt: parsed.data.prompt,
    result: story,
  });

  req.log.info({ userId: decoded.id }, "Story generated");
  res.json({ story });
});

router.post("/ai/image", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const parsed = GenerateImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Prompt required" });
    return;
  }

  const { allowed } = await checkAndDecrementUsage(decoded.id, decoded.email, "image");
  if (!allowed) {
    res.status(403).json({ error: "Free usage limit reached. Please upgrade to continue." });
    return;
  }

  const imageBuffer = await generateImageBuffer(parsed.data.prompt, "1024x1024");
  const base64 = imageBuffer.toString("base64");
  const imageDataUrl = `data:image/png;base64,${base64}`;

  await db.insert(generationsTable).values({
    userId: decoded.id,
    type: "image",
    prompt: parsed.data.prompt,
    result: imageDataUrl,
  });

  req.log.info({ userId: decoded.id }, "Image generated");
  res.json({ image: imageDataUrl });
});

router.post("/ai/shorts", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const parsed = GenerateShortsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Prompt required" });
    return;
  }

  const { allowed } = await checkAndDecrementUsage(decoded.id, decoded.email, "shorts");
  if (!allowed) {
    res.status(403).json({ error: "Free usage limit reached. Please upgrade to continue." });
    return;
  }

  const systemPrompt = `You are an expert YouTube Shorts scriptwriter. Create a compelling, engaging short-form video script based on the user's topic. 
Format it clearly with: Hook (0-3 sec), Main Content (3-55 sec), and CTA (55-60 sec). Include specific dialogue, visual cues, and text overlays.`;

  const completion = await openai.chat.completions.create({
    model: "gpt-5-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: parsed.data.prompt },
    ],
  });

  const short = completion.choices?.[0]?.message?.content ?? "";

  await db.insert(generationsTable).values({
    userId: decoded.id,
    type: "shorts",
    prompt: parsed.data.prompt,
    result: short,
  });

  req.log.info({ userId: decoded.id }, "Shorts script generated");
  res.json({ short });
});

router.post("/ai/video", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const parsed = GenerateVideoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Prompt required" });
    return;
  }

  const { allowed } = await checkAndDecrementUsage(decoded.id, decoded.email, "video");
  if (!allowed) {
    res.status(403).json({ error: "Free usage limit reached. Please upgrade to continue." });
    return;
  }

  const systemPrompt = `You are an expert video director and screenwriter. Create a detailed video concept and script based on the user's idea.
Include: Scene-by-scene breakdown, dialogue/narration, visual descriptions, music/sound suggestions, camera angles, and estimated duration. Be specific and cinematic.`;

  const completion = await openai.chat.completions.create({
    model: "gpt-5-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: parsed.data.prompt },
    ],
  });

  const video = completion.choices?.[0]?.message?.content ?? "";

  await db.insert(generationsTable).values({
    userId: decoded.id,
    type: "video",
    prompt: parsed.data.prompt,
    result: video,
  });

  req.log.info({ userId: decoded.id }, "Video concept generated");
  res.json({ video });
});

router.get("/ai/history", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const history = await db
    .select()
    .from(generationsTable)
    .where(eq(generationsTable.userId, decoded.id))
    .orderBy(desc(generationsTable.createdAt))
    .limit(50);

  res.json(history);
});

export default router;
