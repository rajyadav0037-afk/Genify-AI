import { Router, type IRouter } from "express";
import { pool } from "@workspace/db";

const router: IRouter = Router();

const startTime = Date.now();

function toMB(bytes: number): number {
  return Math.round((bytes / 1024 / 1024) * 100) / 100;
}

router.get("/healthz", async (_req, res) => {
  try {
    let dbStatus = false;
    let dbLatencyMs: number | null = null;

    try {
      const dbStart = Date.now();
      await pool.query("SELECT 1");
      dbLatencyMs = Date.now() - dbStart;
      dbStatus = true;
    } catch {
      dbStatus = false;
    }

    const aiStatus = !!process.env["OPENAI_API_KEY"];

    const uptimeMs = Date.now() - startTime;
    const uptimeSeconds = Math.floor(uptimeMs / 1000);
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = uptimeSeconds % 60;

    const mem = process.memoryUsage();

    res.json({
      status: "OK",
      database: {
        connected: dbStatus ? "Connected" : "Disconnected",
        latencyMs: dbLatencyMs,
      },
      openai: aiStatus ? "Key Present" : "Missing",
      uptime: {
        ms: uptimeMs,
        human: `${hours}h ${minutes}m ${seconds}s`,
      },
      memory: {
        rssMB: toMB(mem.rss),
        heapUsedMB: toMB(mem.heapUsed),
        heapTotalMB: toMB(mem.heapTotal),
        externalMB: toMB(mem.external),
      },
      time: new Date(),
    });
  } catch (err) {
    res.status(500).json({
      status: "ERROR",
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

export default router;
