import { Router, type IRouter } from "express";
import jwt from "jsonwebtoken";
import { db, paymentsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SubmitPaymentBody } from "@workspace/api-zod";
import { JWT_SECRET } from "./auth";

const router: IRouter = Router();

async function authMiddleware(req: any, res: any): Promise<{ id: number; email: string } | null> {
  const authHeader = req.headers.authorization ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return null;
  }

  const token = authHeader.slice(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number; email: string };
    return decoded;
  } catch {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }
}

router.post("/payment/submit", async (req, res): Promise<void> => {
  const decoded = await authMiddleware(req, res);
  if (!decoded) return;

  const parsed = SubmitPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await db.insert(paymentsTable).values({
    userId: decoded.id,
    transactionId: parsed.data.transactionId,
    amount: parsed.data.amount,
    notes: parsed.data.notes ?? null,
    status: "pending",
  });

  req.log.info({ userId: decoded.id }, "Payment submitted");
  res.json({ message: "Payment submitted for review. We will activate your subscription within 24 hours." });
});

export default router;
