import { Router, type IRouter } from "express";
import jwt from "jsonwebtoken";
import { db, usersTable, paymentsTable, generationsTable } from "@workspace/db";
import { eq, count, sum, sql } from "drizzle-orm";
import { ApprovePaymentParams } from "@workspace/api-zod";
import { JWT_SECRET, ADMIN_EMAIL } from "./auth";

const router: IRouter = Router();

async function adminAuthMiddleware(req: any, res: any): Promise<{ id: number; email: string } | null> {
  const authHeader = req.headers.authorization ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return null;
  }

  const token = authHeader.slice(7);
  let decoded: { id: number; email: string };
  try {
    decoded = jwt.verify(token, JWT_SECRET) as { id: number; email: string };
  } catch {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, decoded.id));
  if (!user || (user.email !== ADMIN_EMAIL && !user.isAdmin)) {
    res.status(403).json({ error: "Admin access required" });
    return null;
  }

  return decoded;
}

router.get("/admin/stats", async (req, res): Promise<void> => {
  const decoded = await adminAuthMiddleware(req, res);
  if (!decoded) return;

  const [totalUsersResult] = await db.select({ count: count() }).from(usersTable);
  const [paidUsersResult] = await db.select({ count: count() }).from(usersTable).where(eq(usersTable.isSubscribed, true));
  const [pendingResult] = await db.select({ count: count() }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));
  const [approvedRevenueResult] = await db.select({ total: sum(paymentsTable.amount) }).from(paymentsTable).where(eq(paymentsTable.status, "approved"));

  const [totalGensResult] = await db.select({ count: count() }).from(generationsTable);

  const gensByType = await db
    .select({
      type: generationsTable.type,
      count: count(),
    })
    .from(generationsTable)
    .groupBy(generationsTable.type);

  const generationsByType = {
    story: 0,
    image: 0,
    shorts: 0,
    video: 0,
  };
  for (const row of gensByType) {
    if (row.type in generationsByType) {
      generationsByType[row.type as keyof typeof generationsByType] = row.count;
    }
  }

  const recentCutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const [recentSignupsResult] = await db
    .select({ count: count() })
    .from(usersTable)
    .where(sql`${usersTable.createdAt} >= ${recentCutoff}`);

  const totalUsers = totalUsersResult?.count ?? 0;
  const paidUsers = paidUsersResult?.count ?? 0;

  res.json({
    totalUsers,
    paidUsers,
    freeUsers: totalUsers - paidUsers,
    pendingPayments: pendingResult?.count ?? 0,
    totalRevenue: parseFloat(approvedRevenueResult?.total?.toString() ?? "0"),
    totalGenerations: totalGensResult?.count ?? 0,
    generationsByType,
    recentSignups: recentSignupsResult?.count ?? 0,
  });
});

router.get("/admin/users", async (req, res): Promise<void> => {
  const decoded = await adminAuthMiddleware(req, res);
  if (!decoded) return;

  const users = await db
    .select({
      id: usersTable.id,
      email: usersTable.email,
      isSubscribed: usersTable.isSubscribed,
      freeUsage: usersTable.freeUsage,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(sql`${usersTable.createdAt} DESC`);

  const genCounts = await db
    .select({ userId: generationsTable.userId, count: count() })
    .from(generationsTable)
    .groupBy(generationsTable.userId);

  const genCountMap = new Map(genCounts.map(g => [g.userId, g.count]));

  res.json(users.map(u => ({
    ...u,
    totalGenerations: genCountMap.get(u.id) ?? 0,
  })));
});

router.get("/admin/payments", async (req, res): Promise<void> => {
  const decoded = await adminAuthMiddleware(req, res);
  if (!decoded) return;

  const payments = await db
    .select({
      id: paymentsTable.id,
      userId: paymentsTable.userId,
      transactionId: paymentsTable.transactionId,
      amount: paymentsTable.amount,
      notes: paymentsTable.notes,
      status: paymentsTable.status,
      createdAt: paymentsTable.createdAt,
      userEmail: usersTable.email,
    })
    .from(paymentsTable)
    .leftJoin(usersTable, eq(paymentsTable.userId, usersTable.id))
    .orderBy(sql`${paymentsTable.createdAt} DESC`);

  res.json(payments.map(p => ({
    ...p,
    userEmail: p.userEmail ?? "Unknown",
    notes: p.notes ?? null,
  })));
});

router.post("/admin/payments/:id/approve", async (req, res): Promise<void> => {
  const decoded = await adminAuthMiddleware(req, res);
  if (!decoded) return;

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = ApprovePaymentParams.safeParse({ id: parseInt(raw, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid payment ID" });
    return;
  }

  const [payment] = await db
    .select()
    .from(paymentsTable)
    .where(eq(paymentsTable.id, parsed.data.id));

  if (!payment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  await db
    .update(paymentsTable)
    .set({ status: "approved" })
    .where(eq(paymentsTable.id, payment.id));

  await db
    .update(usersTable)
    .set({ isSubscribed: true, freeUsage: 999 })
    .where(eq(usersTable.id, payment.userId));

  req.log.info({ paymentId: payment.id, userId: payment.userId }, "Payment approved");
  res.json({ message: "Payment approved. User subscription activated." });
});

export default router;
