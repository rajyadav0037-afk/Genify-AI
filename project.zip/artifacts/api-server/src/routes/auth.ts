import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  RegisterBody,
  LoginBody,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL ?? "raj.yadav0037@gmail.com";
const JWT_SECRET = process.env.JWT_SECRET ?? process.env.SESSION_SECRET ?? "fallback-secret";

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    email: user.email,
    isSubscribed: user.isSubscribed,
    isAdmin: user.email === ADMIN_EMAIL || user.isAdmin,
    freeUsage: user.freeUsage,
    usageImage: user.usageImage,
    usageVideo: user.usageVideo,
    usageStory: user.usageStory,
    usageShorts: user.usageShorts,
    createdAt: user.createdAt,
  };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing) {
    res.status(400).json({ error: "Email already registered" });
    return;
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const isAdminUser = email === ADMIN_EMAIL;

  const [user] = await db.insert(usersTable).values({
    email,
    password: hashedPassword,
    isAdmin: isAdminUser,
    isSubscribed: isAdminUser,
    freeUsage: isAdminUser ? 999 : 2,
  }).returning();

  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);

  req.log.info({ userId: user.id }, "User registered");
  res.json({ token, user: formatUser(user) });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);

  req.log.info({ userId: user.id }, "User logged in");
  res.json({ token, user: formatUser(user) });
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const authHeader = req.headers.authorization ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return;
  }

  const token = authHeader.slice(7);

  let decoded: { id: number; email: string };
  try {
    decoded = jwt.verify(token, JWT_SECRET) as { id: number; email: string };
  } catch {
    res.status(401).json({ error: "Invalid token" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, decoded.id));
  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }

  res.json(formatUser(user));
});

export { formatUser, ADMIN_EMAIL, JWT_SECRET };
export default router;
