import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  isSubscribed: boolean("is_subscribed").notNull().default(false),
  isAdmin: boolean("is_admin").notNull().default(false),
  freeUsage: integer("free_usage").notNull().default(2),
  usageImage: integer("usage_image").notNull().default(0),
  usageVideo: integer("usage_video").notNull().default(0),
  usageStory: integer("usage_story").notNull().default(0),
  usageShorts: integer("usage_shorts").notNull().default(0),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
