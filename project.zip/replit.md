# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **AI**: OpenAI via Replit AI Integrations (`@workspace/integrations-openai-ai-server`)
- **Auth**: bcryptjs + JWT (stored in localStorage as `genify_token`)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Application: Genify AI

A SaaS AI creative studio platform with full-stack functionality.

### Features
- **Landing page** (`/`) — marketing page with hero, features, pricing
- **Auth** (`/login`, `/register`) — JWT-based authentication
- **Dashboard** (`/dashboard`) — overview of AI tools and usage status
- **Story Generator** (`/generate/story`) — generate AI stories
- **Image Generator** (`/generate/image`) — generate AI images via gpt-image-1
- **Shorts Generator** (`/generate/shorts`) — generate YouTube Shorts scripts
- **Video Generator** (`/generate/video`) — generate video concepts/scripts
- **Generation History** — per-user history stored in DB
- **Upgrade Page** (`/upgrade`) — submit payment proof for subscription
- **Admin Dashboard** (`/admin`) — stats, user management, payment approvals

### Usage Model
- Free: 2 generations total
- Subscribed: unlimited generations
- Admin (raj.yadav0037@gmail.com): unlimited, can approve payments

### DB Tables
- `users` — email, password, subscription status, usage counters
- `generations` — per-user generation history (type, prompt, result)
- `payments` — payment submissions awaiting admin approval

### Environment Variables
- `JWT_SECRET` / `SESSION_SECRET` — JWT signing secret
- `DATABASE_URL` — PostgreSQL connection string
- `AI_INTEGRATIONS_OPENAI_BASE_URL` — Replit AI proxy URL
- `AI_INTEGRATIONS_OPENAI_API_KEY` — Replit AI proxy key
- `ADMIN_EMAIL` — override admin email (default: raj.yadav0037@gmail.com)
